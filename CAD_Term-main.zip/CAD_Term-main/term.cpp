#include <bits/stdc++.h>
using namespace std;

enum GridState
{
    EMPTY = 0,
    FILLED = 1,
    VERTICAL_LINE = 2,
    RED_CIRCLE_START = 3,
    RED_CIRCLE_END = 4
};
struct Column
{
    int col, up, down;
    void init(int _curSt, int _curUp, int _curDown) { col = _curSt, up = _curUp, down = _curDown; }
    Column(int _col = -1, int _up = -1, int _down = -1) : col(_col), up(_up), down(_down) {}
} Cur[1001];

struct Interval
{
    Column start, end;
    int id, track;
    bool placed;
    Interval(int _id, Column _st, Column _ed) : id(_id), start(_st), end(_ed) {}
    int wire_len(int totalTrack)
    {
        int wr = 0;
        wr += (id == start.up) ? track : totalTrack - track + 1;
        wr += (id == end.down) ? track : totalTrack - track + 1;
        return wr;
    }
};

struct Cost
{
    int wr, v;
    Cost(int _wr = 0, int _v = 0) : wr(_wr), v(_v) {}
    bool operator<(const Cost &bCost)
    {
        if (wr == bCost.wr)
            return v < bCost.v;
        return wr < bCost.wr;
    }
};

int up_pins[1001], down_pins[1001];
int col_nums, net_nums;
vector<Interval> intervals;
int grid[1001][1001] = {0};

bool interval_comp(Interval a, Interval b)
{
    if (a.start.col == b.start.col)
        return a.start.up == a.id;
    return a.start.col < b.start.col;
}

void add_interval(int index, Column cur)
{
    if (index == 0)
        return;
    intervals.push_back(Interval(index, Cur[index], cur));
    Cur[index] = cur;
}

void init_interval()
{
    for (int i = 0; i < col_nums; ++i)
    {
        int up_pin = up_pins[i], down_pin = down_pins[i];
        if (Cur[up_pin].col == -1)
            Cur[up_pin].init(i + 1, up_pin, down_pin);
        else
            add_interval(up_pin, Column(i + 1, up_pin, down_pin));

        if (Cur[down_pin].col == -1)
            Cur[down_pin].init(i + 1, up_pin, down_pin);
        else
            add_interval(down_pin, Column(i + 1, up_pin, down_pin));
    }
    sort(intervals.begin(), intervals.end(), interval_comp);
}

void dogleg(int &Track, Cost &Cost)
{
    int track = 1, prev, prev_id;
    vector<Interval> temp;
    do
    {
        prev = 0, prev_id = 0;
        for (auto &e : intervals)
        {
            if (!e.placed)
            {
                if (prev < e.start.col || (prev == e.start.col && prev_id == e.id))
                {
                    if (prev_id == e.id)
                        Cost.v -= 2;

                    e.track = track, e.placed = true;
                    temp.push_back(e);
                    prev = e.end.col, prev_id = e.id;
                    Cost.v += 2;
                }
            }
        }
        if (prev)
            track++;
    } while (prev != 0);
    intervals = temp;
    Track = track - 1;
    int preTrack = 0, preId = 0;
    for (auto &i : intervals)
    {
        Cost.wr += i.wire_len(Track);
        Cost.wr += (i.end.col) - i.start.col;
        if (preTrack == i.track && preId == i.id)
            Cost.wr -= 1;
        preTrack = i.track, preId = i.id;
    }
}

void draw(int totalTrack, int curTrack, int col, bool up)
{
    if (up)
        for (int i = 1; i <= curTrack; ++i)
            grid[i][col] = VERTICAL_LINE;
    else
        for (int i = curTrack; i <= totalTrack; ++i)
            grid[i][col] = VERTICAL_LINE;
}

void result(int totalTrack)
{
    for (auto i : intervals)
    {
        draw(totalTrack, i.track, i.start.col, i.start.up == i.id);
        draw(totalTrack, i.track, i.end.col, i.end.up == i.id);
    }

    for (int i = 0; i < intervals.size(); ++i)
    {
        Interval &internal = intervals[i];
        for (int i = internal.start.col; i <= internal.end.col; ++i)
            grid[internal.track][i] = FILLED;

        if (i - 1 >= 0 && intervals[i - 1].track == internal.track && intervals[i - 1].id == internal.id)
            grid[internal.track][internal.start.col] = RED_CIRCLE_END;
        else
            grid[internal.track][internal.start.col] = RED_CIRCLE_START;
        grid[internal.track][internal.end.col] = RED_CIRCLE_END;
    }

    for (int i = 0; i < col_nums; ++i)
        printf("%4d", up_pins[i]);
    printf("\n");
    for (int i = 0; i < col_nums; ++i)
    {
        if (up_pins[i] != 0)
            printf("   ┃");
        else
            printf("    ");
    }
    printf("\n");
    for (int i = 1; i <= totalTrack; ++i)
    {
        for (int j = 1; j <= col_nums; ++j)
        {
            if (grid[i][j] == FILLED)
                printf("━━━━");
            else if (grid[i][j] == VERTICAL_LINE)
                printf("   ┃");
            else if (grid[i][j] == RED_CIRCLE_START)
                printf("  🔴");
            else if (grid[i][j] == RED_CIRCLE_END)
                printf("━━🔴");
            else
                printf("    ");
        }
        printf("\n");
    }
    for (int i = 0; i < col_nums; ++i)
    {
        if (down_pins[i] != 0)
            printf("   ┃");
        else
            printf("    ");
    }
    printf("\n");
    for (int i = 0; i < col_nums; ++i)
        printf("%4d", down_pins[i]);
    printf("\n");
}

int main(int argc, char *argv[])
{
    if (argc < 2)
    {
        std::cerr << "Usage: " << argv[0] << " <filename>\n";
        return 1;
    }
    ifstream input(argv[1]);
    input >> col_nums >> net_nums;
    for (int i = 0; i < col_nums; ++i)
        input >> up_pins[i] >> down_pins[i];
    input.close();
    init_interval();
    Cost c;
    int track;
    dogleg(track, c);

    int preTrack = 0;
    for (auto i : intervals)
    {
        if (preTrack != i.track)
        {
            printf("\nTrack:%d\n", i.track);
            preTrack = i.track;
        }
        printf("Net: %d, (%d, %d)\n", i.id, i.start.col, i.end.col);
    }
    printf("\nCost cost: (%d,%d,%d)\n", track, c.wr, c.v);
    printf("\nResult\n\n");
    result(track);
}
