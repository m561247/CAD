# CAD_Term
## Steps

1. **Initialize Intervals**: Add all possible intervals to `intervals`.
2. **Sort Intervals**: Perform sorting on the `intervals`.
3. **Arrange Sorted Intervals**: Start arranging the sorted intervals from `track1`.
4. **Print Results**: Output the final results using `print`.
## Usage

**Environment**:
- **OS**: Ubuntu

**Compilation**:
- Use the `make` command for compilation.

**Execution**:
- To run the program, execute: `./term filename`

