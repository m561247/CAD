/*
 * Revision Control Information
 *
 * $Source: /users/pchong/CVS/sis/sis/graphics/graphics.h,v $
 * $Author: pchong $
 * $Revision: 1.2 $
 * $Date: 2004/02/09 07:35:29 $
 *
 */
#ifndef GRAPHICS_H
#define GRAPHICS_H

extern void init_graphics (void);
extern void end_graphics (void);

#endif
