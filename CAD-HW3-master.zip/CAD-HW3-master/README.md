# README

## Part 1

### for Question 1

## Part 2

### for Question 2

## Difference between two questions
### nodes reduced from 25 to 22
